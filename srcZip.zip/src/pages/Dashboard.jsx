import React from 'react';
import PatientForm from '../components/PatientForm';

export default function Dashboard({ patients, onAdd, onView }) {
  return (
    <div className="dashboard animate-fade-in">
      <h1>Dashboard</h1>
      <PatientForm onAdd={onAdd} />
      <ul className="patient-list">
        {patients.map((patient) => (
          <li key={patient.id}>
            <button className="view-btn" onClick={() => onView(patient.id)}>{patient.name}</button>
          </li>
        ))}
      </ul>
    </div>
  );
}